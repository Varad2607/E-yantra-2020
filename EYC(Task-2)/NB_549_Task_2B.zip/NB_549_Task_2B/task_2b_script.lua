--[[
*****************************************************************************************
*
*        		===============================================
*           		Nirikshak Bot (NB) Theme (eYRC 2020-21)
*        		===============================================
*
*  This Lua script is to implement Task 2B of Nirikshak Bot (NB) Theme (eYRC 2020-21).
*  
*  This software is made available on an "AS IS WHERE IS BASIS".
*  Licensee/end user indemnifies and will keep e-Yantra indemnified from
*  any and all claim(s) that emanate from the use of the Software or 
*  breach of the terms of this agreement.
*  
*  e-Yantra - An MHRD project under National Mission on Education using ICT (NMEICT)
*
*****************************************************************************************
]]--


--[[
# Team ID:			[ Team-ID ]
# Author List:		[ Names of team members worked on this file separated by Comma: Name1, Name2, ... ]
# Filename:			task_2b
# Functions:        createWall, saveTexture, retrieveTexture, reapplyTexture, receiveData, generateHorizontalWalls, 
#                   generateVerticalWalls, deleteWalls, createMaze, sysCall_init, sysCall_beforeSimulation
#                   sysCall_afterSimulation, sysCall_cleanup
# 					[ Comma separated list of functions in this file ]
# Global variables:	
# 					[ List of global variables defined in this file ]
]]--

--[[
##################### GLOBAL VARIABLES #######################
## You can add global variables in this section according   ##
## to your requirement.                                     ##
## DO NOT TAMPER WITH THE ALREADY DEFINED GLOBAL VARIABLES. ##
##############################################################
]]--

wall_Hori_Handle = {}
wall_Vert_Handle = {}

--Vertical_Table = {}



maze_array = {}
baseHandle = -1       --Do not change or delete this variable
textureID = -1        --Do not change or delete this variable
textureData = -1       --Do not change or delete this variable
--############################################################

--[[
##################### HELPER FUNCTIONS #######################
## You can add helper functions in this section according   ##
## to your requirement.                                     ##
## DO NOT MODIFY OR CHANGE THE ALREADY DEFINED HELPER       ##
## FUNCTIONS                                                ##
##############################################################
]]--

--[[
**************************************************************
	Function Name : createWall()
    Purpose:
	---
	Creates a black-colored wall of dimensions 90cm x 10cm x 10cm

	Input Arguments:
	---
	None
	
	Returns:
	---
	wallObjectHandle : number
    
    returns the object handle of the created wall
	
	Example call:
	---
	wallObjectHandle = createWall()
**************************************************************	
]]--
function createWall()
    wallObjectHandle = sim.createPureShape(0, 26, {0.09, 0.01, 0.1}, 0, nil)
    sim.setShapeColor(wallObjectHandle, nil, sim.colorcomponent_ambient_diffuse, {0, 0, 0})
    sim.setObjectSpecialProperty(wallObjectHandle, sim.objectspecialproperty_collidable)
    sim.setObjectSpecialProperty(wallObjectHandle, sim.objectspecialproperty_measurable)
    sim.setObjectSpecialProperty(wallObjectHandle, sim.objectspecialproperty_detectable_all)
    sim.setObjectSpecialProperty(wallObjectHandle, sim.objectspecialproperty_renderable)
    return wallObjectHandle
end

--[[
**************************************************************
  YOU ARE NOT ALLOWED TO MODIFY OR CALL THIS HELPER FUNCTION
**************************************************************
	Function Name : saveTexture()
    Purpose:
	---
	Reads and initializes the applied texture to Base object
    and saves it to a file.

	Input Arguments:
	---
	None
	
	Returns:
	---
	None
	
	Example call:
	---
	saveTexture()
**************************************************************	
]]--
function saveTexture()
    baseHandle = sim.getObjectHandle("Base")
    textureID = sim.getShapeTextureId(baseHandle)
    textureData=sim.readTexture(textureID ,0,0,0,0,0)
    sim.saveImage(textureData, {512,512}, 0, "models/other/base_template.png", -1)
end
--[[
**************************************************************
  YOU ARE NOT ALLOWED TO MODIFY OR CALL THIS HELPER FUNCTION
**************************************************************
	Function Name : retrieveTexture()
    Purpose:
	---
	Loads texture from file.

	Input Arguments:
	---
	None
	
	Returns:
	---
	None
	
	Example call:
	---
	retrieveTexture()
**************************************************************	
]]--
function retrieveTexture()
    textureData, resolution = sim.loadImage(0, "models/other/base_template.png") 
end

--[[
**************************************************************
  YOU ARE NOT ALLOWED TO MODIFY OR CALL THIS HELPER FUNCTION
**************************************************************
	Function Name : reapplyTexture()
    Purpose:
	---
	Re-applies texture to Base object

	Input Arguments:
	---
	None
	
	Returns:
	---
	None
	
	Example call:
	---
    reapplyTexture()
**************************************************************	
]]--
function reapplyTexture()
    plane, textureID = sim.createTexture("", 0, nil, {1.01, 1.01}, nil, 0, {512, 512})
    sim.writeTexture(textureID, 0, textureData, 0, 0, 0, 0, 0)
    sim.setShapeTexture(baseHandle, textureID, sim.texturemap_plane, 0, {1.01, 1.01},nil,nil)
    sim.removeObject(plane)
end

--############################################################

--[[
**************************************************************
	Function Name : receiveData()
    Purpose:
	---
	Receives data via Remote API. This function is called by 
    simx.callScriptFunction() in the python code (task_2b.py)

	Input Arguments:
	---
	inInts : Table of Ints
    inFloats : Table of Floats
    inStrings : Table of Strings
    inBuffer : string
	
	Returns:
	---
	inInts : Table of Ints
    inFloats : Table of Floats
    inStrings : Table of Strings
    inBuffer : string
    
    These 4 variables represent the data being passed from remote
    API client(python) to the CoppeliaSim scene
	
	Example call:
	---
	N/A
    
    Hint:
    ---
    You might want to study this link to understand simx.callScriptFunction()
    better 
    https://www.coppeliarobotics.com/helpFiles/en/remoteApiExtension.htm
**************************************************************	
]]--
function receiveData(inInts,inFloats,inStrings,inBuffer)

    --*******************************************************
    --               ADD YOUR CODE HERE
    
    
    maze_array = inInts
    print(maze_array)
    
    


        
    --*******************************************************
    return inInts, inFloats, inStrings, inBuffer
end

--[[
**************************************************************
	Function Name : generateHorizontalWalls()
    Purpose:
	---
	Generates all the Horizontal Walls in the scene.

	Input Arguments:
	---
	None
	
	Returns:
	---
    None
	
	Example call:
	---
	generateHorizontalWalls()
**************************************************************	
]]--
function generateHorizontalWalls()

    --*******************************************************
    --               ADD YOUR CODE HERE
    
    
    --Basehandle=sim.getObjectHandle('Base')
    --print(maze_array)
    
    
    
    
    
    --i means row
    --j means column
    wall_Hori_Handle = {}
    
    for i = 0,10
    do
        for j = 0,9
        do
            
            wallobjecthandle = createWall()
            table.insert(wall_Hori_Handle,wallobjecthandle)
            sim.setObjectParent(wallobjecthandle,sim.getObjectHandle("Base"),True)
            position = sim.getObjectPosition(wallobjecthandle,-1)
            position[1] =  - 0.45 + (j*0.1)
            position[2] =  0.5 - (i*0.1)
            position[3] = 0.08
            
          
            
            
            sim.setObjectPosition(wallobjecthandle,-1,position)
            
            --sim.removeObject(wallobjecthandle)
           
           
            
            --print(position)
        end
    end
    
    
            
            
            
    
    
    
    


        
    --*******************************************************
end

--[[
**************************************************************
	Function Name : generateVerticalWalls()
    Purpose:
	---
	Generates all the Vertical Walls in the scene.

	Input Arguments:
	---
	None
	
	Returns:
	---
    None
	
	Example call:
	---
	generateVerticalWalls()
**************************************************************	
]]--
function generateVerticalWalls()

    --*******************************************************
    --               ADD YOUR CODE HERE
    
    wall_Vert_Handle = {}
    for i = 0,10
    do
        for j = 0,9
        do
            
            wallobjecthandle = createWall()
            table.insert(wall_Vert_Handle,wallobjecthandle)
            sim.setObjectOrientation(wallobjecthandle,-1,{0,0,1.571425})
            sim.setObjectParent(wallobjecthandle,sim.getObjectHandle("Base"),True)
            position = sim.getObjectPosition(wallobjecthandle,-1)
            position[2] =   0.45 - (j*0.1)
            position[3] =  0.08
            position[1] = -0.5 + (i*0.1)
            
          
            
            
            sim.setObjectPosition(wallobjecthandle,-1,position)
            
            --sim.removeObject(wallobjecthandle)
            
                
           
           
            
            --print(position)
        end
    end
    
    

    


        
    --*******************************************************
end

--[[
**************************************************************
	Function Name : deleteWalls()
    Purpose:
	---
	Deletes all the walls in the given scene

	Input Arguments:
	---
	None
	
	Returns:
	---
    None
	
	Example call:
	---
	deleteWalls()
**************************************************************	
]]--
function deleteWalls()

    --*******************************************************
    --               ADD YOUR CODE HERE
    
    
    west_wall = {}
    north_wall = {}
    east_wall = {}
    south_wall = {}
    
    
    
    for i = 1,100
    do
    
        if(maze_array[i] == 0)
        then
        
            table.insert(west_wall,0)
            table.insert(north_wall,0)
            table.insert(east_wall,0)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 1)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,0)
            table.insert(east_wall,0)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 2)
        then
            table.insert(west_wall,0)
            table.insert(north_wall,1)
            table.insert(east_wall,0)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 3)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,1)
            table.insert(east_wall,0)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 4)
        then
            table.insert(west_wall,0)
            table.insert(north_wall,0)
            table.insert(east_wall,1)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 5)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,0)
            table.insert(east_wall,1)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 6)
        then
            table.insert(west_wall,0)
            table.insert(north_wall,1)
            table.insert(east_wall,1)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 7)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,1)
            table.insert(east_wall,1)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 8)
        then
            table.insert(west_wall,0)
            table.insert(north_wall,0)
            table.insert(east_wall,0)
            table.insert(south_wall,1)
            
        elseif(maze_array[i] == 9)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,0)
            table.insert(east_wall,0)
            table.insert(south_wall,1)
            
        elseif(maze_array[i] == 10)
        then
            table.insert(west_wall,0)
            table.insert(north_wall,1)
            table.insert(east_wall,0)
            table.insert(south_wall,1)
            
        elseif(maze_array[i] == 11)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,1)
            table.insert(east_wall,0)
            table.insert(south_wall,1)
            
        elseif(maze_array[i] == 12)
        then
            table.insert(west_wall,0)
            table.insert(north_wall,0)
            table.insert(east_wall,1)
            table.insert(south_wall,1)
        
        
        elseif(maze_array[i] == 13)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,0)
            table.insert(east_wall,1)
            table.insert(south_wall,1)
            
        elseif(maze_array[i] == 14)
        then
            table.insert(west_wall,0)
            table.insert(north_wall,1)
            table.insert(east_wall,1)
            table.insert(south_wall,1)
            
        elseif(maze_array[i] == 15)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,1)
            table.insert(east_wall,1)
            table.insert(south_wall,1)
            
        end
        
    
    
    end
    
    
    Vertical_Table = {}
    
    for i = 0,9
    do
        var1 = 1 + i
        for j = 1,10
        do
            
            table.insert(Vertical_Table,west_wall[var1])
            var1 = var1 + 10
            
        end
    end
    
    
    
    
    
    hori = 1
    for i = 1,11
    do
        for j = 1,10
        do
        
            if wall_Hori_Handle[hori] ~= -1 and north_wall[hori] == 1
            then
                sim.removeObject(wall_Hori_Handle[hori])
            end
            
            if i == 11 and wall_Hori_Handle[hori] ~= -1
            then
                sim.removeObject(wall_Hori_Handle[hori])
                
            end
            hori = hori + 1
        end
    end
    
    verti = 1
    for i = 1,11
    do
        for j = 1,10
        do
        
            if wall_Vert_Handle[verti] ~= -1 and Vertical_Table[verti] == 1
            then
                sim.removeObject(wall_Vert_Handle[verti])
            end
            
            if i == 11 and wall_Vert_Handle[verti] ~= -1
            then
                sim.removeObject(wall_Vert_Handle[verti])
                
            end
            verti = verti + 1
        end
    end
    
    
    
    
        
    
    
    
    
            
        
            
    
    


        
    --*******************************************************
end


--[[
**************************************************************
  YOU CAN DEFINE YOUR OWN INPUT AND OUTPUT PARAMETERS FOR THIS
                          FUNCTION
**************************************************************
	Function Name : createMaze()
    Purpose:
	---
	Creates the maze in the given scene by deleting specific 
    horizontal and vertical walls

	Input Arguments:
	---
	None
	
	Returns:
	---
    None
	
	Example call:
	---
	createMaze()
**************************************************************	
]]--
function createMaze()
    
    --*******************************************************
    --               ADD YOUR CODE HERE
    
    --print("MA",maze_array)
    --print("MA Length",#maze_array)
    
    --print("wall_Hori_Handle",wall_Hori_Handle)
    --print("WH",#wall_Hori_Handle)
    
    --print("wall_Vert_Handle",wall_Vert_Handle)
    --print("WH",#wall_Vert_Handle)
    
    west_wall = {}
    north_wall = {}
    east_wall = {}
    south_wall = {}
    
    
    
    for i = 1,100
    do
    
        if(maze_array[i] == 0)
        then
        
            table.insert(west_wall,0)
            table.insert(north_wall,0)
            table.insert(east_wall,0)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 1)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,0)
            table.insert(east_wall,0)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 2)
        then
            table.insert(west_wall,0)
            table.insert(north_wall,1)
            table.insert(east_wall,0)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 3)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,1)
            table.insert(east_wall,0)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 4)
        then
            table.insert(west_wall,0)
            table.insert(north_wall,0)
            table.insert(east_wall,1)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 5)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,0)
            table.insert(east_wall,1)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 6)
        then
            table.insert(west_wall,0)
            table.insert(north_wall,1)
            table.insert(east_wall,1)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 7)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,1)
            table.insert(east_wall,1)
            table.insert(south_wall,0)
            
        elseif(maze_array[i] == 8)
        then
            table.insert(west_wall,0)
            table.insert(north_wall,0)
            table.insert(east_wall,0)
            table.insert(south_wall,1)
            
        elseif(maze_array[i] == 9)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,0)
            table.insert(east_wall,0)
            table.insert(south_wall,1)
            
        elseif(maze_array[i] == 10)
        then
            table.insert(west_wall,0)
            table.insert(north_wall,1)
            table.insert(east_wall,0)
            table.insert(south_wall,1)
            
        elseif(maze_array[i] == 11)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,1)
            table.insert(east_wall,0)
            table.insert(south_wall,1)
            
        elseif(maze_array[i] == 12)
        then
            table.insert(west_wall,0)
            table.insert(north_wall,0)
            table.insert(east_wall,1)
            table.insert(south_wall,1)
        
        
        elseif(maze_array[i] == 13)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,0)
            table.insert(east_wall,1)
            table.insert(south_wall,1)
            
        elseif(maze_array[i] == 14)
        then
            table.insert(west_wall,0)
            table.insert(north_wall,1)
            table.insert(east_wall,1)
            table.insert(south_wall,1)
            
        elseif(maze_array[i] == 15)
        then
            table.insert(west_wall,1)
            table.insert(north_wall,1)
            table.insert(east_wall,1)
            table.insert(south_wall,1)
            
        end
        
    
    
    end
    
    
    
    --print(west_wall)
    --print(north_wall)
    --print(east_wall)
    --print(south_wall)
    
    
    
    
    
    
    --print(removeid)
    --print(If)
    --print(#wall_Hori_Handle)
    --print(#wall_Vert_Handle)
    
    var = 1
    for i = 0,9
    do
        for j = 0,9
        do
        
            if north_wall[var] == 0 and wall_Hori_Handle[var] ~= -1
            then
                sim.removeObject(wall_Hori_Handle[var])
            end
            var =  var + 1
        end
    end
    
    
    

    
    
    
    Vertical_Table = {}
    
    for i = 0,9
    do
        var1 = 1 + i
        for j = 1,10
        do
            
            
            
            table.insert(Vertical_Table,west_wall[var1])
        
            var1 = var1 + 10
            
        end
    end
    
    --print("Vertical Table",Vertical_Table)
    --print(#Vertical_Table)
    
    var2 = 0
    for i = 0,9
    do
        for j = 0,9
        do
            var2 =  var2 + 1
            if Vertical_Table[var2] == 0 and wall_Vert_Handle[var2] ~= -1
            then
                sim.removeObject(wall_Vert_Handle[var2])
            end
            
        end
    end
    
    
    
    
    
    
        
    
    
    
    
    
    
    
        
            
            
            
            
 
    
    
            
        
            
    
    
    
            
        
            
            
        
    
    


        
    --*******************************************************
end



--[[
**************************************************************
	Function Name : sysCall_init()
    Purpose:
	---
	Can be used for initialization of parameters
    
	Input Arguments:
	---
	None
	
	Returns:
	---
    None
	
	Example call:
	---
	N/A
**************************************************************	
]]--
function sysCall_init()

    if pcall(saveTexture) then -- Do not delete or modify this section
        print("Successfully saved texture")
    else
        print("Texture does not exist. Importing texture from file..")
        retrieveTexture()
        reapplyTexture()
    end     
end

--[[
**************************************************************
        YOU ARE NOT ALLOWED TO MODIFY THIS FUNCTION. 
**************************************************************
	Function Name : sysCall_beforeSimulation()
    Purpose:
	---
	This is executed before simulation starts
    
	Input Arguments:
	---
	None
	
	Returns:
	---
    None
	
	Example call:
	---
	N/A
**************************************************************	
]]--
function sysCall_beforeSimulation()
    
    sim.setShapeTexture(baseHandle, -1, sim.texturemap_plane, 0, {1.01, 1.01},nil,nil) -- Do not delete or modify this line
    
    generateHorizontalWalls()
    generateVerticalWalls()
    createMaze()
end

--[[
**************************************************************
        YOU ARE NOT ALLOWED TO MODIFY THIS FUNCTION. 
**************************************************************
	Function Name : sysCall_afterSimulation()
    Purpose:
	---
	This is executed after simulation ends
    
	Input Arguments:
	---
	None
	
	Returns:
	---
    None
	
	Example call:
	---
	N/A
**************************************************************	
]]--
function sysCall_afterSimulation()
    -- is executed after a simulation ends
    deleteWalls()
    reapplyTexture() -- Do not delete or modify this line
end

function sysCall_cleanup()
    -- do some clean-up here
end

-- See the user manual or the available code snippets for additional callback functions and details




